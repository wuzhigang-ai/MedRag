import type { Note } from './types';

export type BackgroundMode = 'solid' | 'silk' | 'moonlit' | 'rain';

export interface SiteConfig {
  title: string
  description: string
  language: string
}

export interface HeaderConfig {
  brandMark: string
  noteCountSuffix: string
  editorViewLabel: string
  graphViewLabel: string
  backgroundButtonTitle: string
  importButtonLabel: string
}

export interface BackgroundOption {
  id: BackgroundMode
  label: string
}

export interface SolidColorOption {
  color: string
  label: string
}

export interface BackgroundConfig {
  defaultMode: BackgroundMode
  defaultSolidColor: string
  options: BackgroundOption[]
  solidColors: SolidColorOption[]
}

export interface SidebarConfig {
  searchPlaceholder: string
  noResultsLabel: string
  emptyNotesLabel: string
  selectAllLabel: string
  clearSelectionLabel: string
  selectedCountSuffix: string
  deleteSelectedLabel: string
  cancelLabel: string
  newNoteLabel: string
  manageLabel: string
}

export interface EditorConfig {
  editLabel: string
  previewLabel: string
  sourceLabel: string
  deleteLabel: string
  cancelLabel: string
  titlePlaceholder: string
  contentPlaceholder: string
  outgoingLinksLabel: string
  incomingLinksLabel: string
}

export interface GraphConfig {
  notesLabel: string
  connectionsLabel: string
  emptyGraphLabel: string
}

export interface MoonConfig {
  phaseLabels: string[]
}

export interface AppConfig {
  emptyStateLabel: string
}

export interface StorageConfig {
  notesKey: string
}

export interface StarterNote extends Pick<Note, 'title' | 'content' | 'tags' | 'source'> {}

export const siteConfig: SiteConfig = {
  title: "大模型学习笔记",
  description: "大语言模型学习笔记 - 从Transformer到AGI的知识探索",
  language: "zh-CN",
}

export const headerConfig: HeaderConfig = {
  brandMark: "LLM笔记",
  noteCountSuffix: "条笔记",
  editorViewLabel: "编辑",
  graphViewLabel: "图谱",
  backgroundButtonTitle: "切换背景",
  importButtonLabel: "",
}

export const backgroundConfig: BackgroundConfig = {
  defaultMode: 'moonlit',
  defaultSolidColor: '#000000',
  options: [
    { id: 'moonlit', label: "月夜涟漪" },
    { id: 'silk', label: "丝绸流场" },
    { id: 'rain', label: "雨落寒窗" },
    { id: 'solid', label: "纯色" },
  ],
  solidColors: [
    { color: '#000000', label: "墨黑" },
    { color: '#1a1a2e', label: "深蓝" },
    { color: '#1a1308', label: "棕褐" },
    { color: '#0d1f0d', label: "墨绿" },
  ],
}

export const sidebarConfig: SidebarConfig = {
  searchPlaceholder: "搜索学习笔记...",
  noResultsLabel: "未找到匹配笔记",
  emptyNotesLabel: "暂无笔记",
  selectAllLabel: "全选",
  clearSelectionLabel: "取消全选",
  selectedCountSuffix: "条已选",
  deleteSelectedLabel: "删除",
  cancelLabel: "取消",
  newNoteLabel: "新笔记",
  manageLabel: "管理",
}

export const editorConfig: EditorConfig = {
  editLabel: "编辑",
  previewLabel: "预览",
  sourceLabel: "来源",
  deleteLabel: "删除",
  cancelLabel: "取消",
  titlePlaceholder: "笔记标题...",
  contentPlaceholder: "用 [[标题]] 创建 Wiki 链接，支持 Markdown 语法...",
  outgoingLinksLabel: "出链:",
  incomingLinksLabel: "反链:",
}

export const graphConfig: GraphConfig = {
  notesLabel: "个笔记",
  connectionsLabel: "条连接",
  emptyGraphLabel: "暂无笔记，创建第一条笔记来开始",
}

export const moonConfig: MoonConfig = {
  phaseLabels: ["新月", "蛾眉月", "上弦月", "盈凸月", "满月", "亏凸月", "下弦月", "残月"],
}

export const appConfig: AppConfig = {
  emptyStateLabel: "选择或创建一个笔记开始",
}

export const storageConfig: StorageConfig = {
  notesKey: "llm-notes-v1",
}

export const starterNotes: StarterNote[] = [
  {
    title: "大语言模型概述",
    content: `# 大语言模型概述

**大语言模型**（Large Language Model，简称LLM）是基于深度学习技术构建的人工智能模型，专门用于理解和生成自然语言。它们通过在海量文本数据上进行训练，学会了语言的统计规律和语义表示。

## 核心特征

- **参数量巨大**：从数十亿到数万亿不等
- **涌现能力**：规模达到某个阈值后突然表现出新的能力
- **上下文学习**：通过提示词（prompt）就能完成新任务，无需微调
- **多任务通用**：一个模型可以处理翻译、摘要、问答、代码生成等多种任务

## 发展历程

| 时间 | 里程碑 |
|------|--------|
| 2017 | Transformer架构提出 |
| 2018 | GPT-1、BERT发布 |
| 2019 | GPT-2发布（15亿参数） |
| 2020 | GPT-3发布（1750亿参数） |
| 2022 | ChatGPT发布，引发AI革命 |
| 2023 | GPT-4、Claude、Gemini等大模型涌现 |
| 2024 | 多模态大模型、推理模型（o1）出现 |

## 主要代表模型

- **OpenAI**：GPT系列、GPT-4、o1推理模型
- **Anthropic**：Claude系列
- **Google**：Gemini、PaLM
- **Meta**：LLaMA系列（开源）
- **DeepSeek**：DeepSeek-V3、DeepSeek-R1
- **阿里**：通义千问（Qwen）

参见[[Transformer架构]]、[[预训练与微调]]、[[提示工程]]`,
    tags: ["概述", "AI", "LLM"],
    source: "",
  },
  {
    title: "Transformer架构",
    content: `# Transformer架构

**Transformer**是2017年Google在论文《Attention Is All You Need》中提出的神经网络架构，它彻底改变了自然语言处理领域，成为所有现代大语言模型的基础。

## 核心创新

Transformer完全基于**注意力机制**（Attention），摒弃了之前广泛使用的循环神经网络（RNN）和卷积神经网络（CNN）。

> "Attention Is All You Need" —— 论文标题本身就说明了核心思想

## 架构组成

Transformer由**编码器**（Encoder）和**解码器**（Decoder）两部分组成：

### 编码器（Encoder）

- 由N个相同的编码器层堆叠（原论文中N=6）
- 每层包含：
  1. **多头自注意力机制** —— 让每个词关注序列中所有其他词
  2. **前馈神经网络** —— 对每个位置独立进行非线性变换
  3. **层归一化 + 残差连接** —— 稳定训练

### 解码器（Decoder）

- 同样由N个相同的解码器层堆叠
- 每层额外包含**掩码多头注意力** —— 防止看到未来的词
- 最终通过Softmax输出概率分布

## 关键组件

### 位置编码（Positional Encoding）

由于Transformer没有循环结构，需要显式注入位置信息：

\`\`\`
PE(pos, 2i) = sin(pos / 10000^(2i/d_model))
PE(pos, 2i+1) = cos(pos / 10000^(2i/d_model))
\`\`\`

### 多头注意力（Multi-Head Attention）

将注意力机制并行执行多次，让模型在不同表示子空间中捕捉不同的关系模式。

## 为什么Transformer如此强大

1. **并行计算** —— 不像RNN需要顺序处理
2. **长距离依赖** —— 注意力可以直接连接任意两个位置
3. **可扩展性** —— 堆叠更多层、增加更多参数就能持续提升性能

参见[[注意力机制]]、[[大语言模型概述]]、[[预训练与微调]]`,
    tags: ["架构", "Transformer", "深度学习"],
    source: "Vaswani et al., 'Attention Is All You Need', NeurIPS 2017",
  },
  {
    title: "注意力机制",
    content: `# 注意力机制

**注意力机制**（Attention Mechanism）是深度学习中最具革命性的创新之一，它让模型能够动态地关注输入中最相关的部分。

## 直观理解

注意力机制模仿人类的注意力：当我们阅读一段话时，不会对所有词给予同等的关注，而是会根据当前任务聚焦于关键信息。

## Scaled Dot-Product Attention

Transformer中使用的注意力计算：

\`\`\`
Attention(Q, K, V) = softmax(QK^T / √d_k) · V
\`\`\`

### 三个关键矩阵

| 矩阵 | 含义 | 作用 |
|------|------|------|
| **Q** (Query) | 查询 | 当前位置想"问什么" |
| **K** (Key) | 键 | 其他位置的"标签" |
| **V** (Value) | 值 | 其他位置的"实际内容" |

### 计算步骤

1. 计算Q和K的点积，得到注意力分数
2. 除以√d_k进行缩放（防止Softmax梯度消失）
3. Softmax归一化为概率分布
4. 与V相乘，得到加权求和的输出

## 自注意力 vs 交叉注意力

### 自注意力（Self-Attention）

Q、K、V都来自同一个输入序列。每个词都可以"看"到序列中所有其他词。

> 例：在"The cat sat on the mat"中，处理"sat"时，自注意力会让它关注到"cat"和"mat"。

### 交叉注意力（Cross-Attention）

Q来自解码器，K和V来自编码器。用于seq2seq任务中让解码器关注编码器的输出。

## 多头注意力（Multi-Head Attention）

将注意力计算并行执行h次（通常h=8或16），每次使用不同的线性投影：

\`\`\`
MultiHead(Q,K,V) = Concat(head_1, ..., head_h) · W^O
\`\`\`

其中每个head_i = Attention(QW_i^Q, KW_i^K, VW_i^V)

### 为什么需要多头？

- 不同头可以学习不同的关系类型
- 一个头可能学习语法关系，另一个学习语义关系
- 增加模型的表达能力

## 掩码注意力（Masked Attention）

在解码器中，使用上三角掩码矩阵防止位置i关注到位置>i的词，确保自回归生成。

## 应用扩展

- **视觉Transformer（ViT）**：将注意力用于图像处理
- **图注意力网络（GAT）**：将注意力用于图结构数据
- **多模态注意力**：跨模态注意力（如图像-文本对齐）

参见[[Transformer架构]]、[[大语言模型概述]]`,
    tags: ["注意力机制", "深度学习", "核心概念"],
    source: "",
  },
  {
    title: "预训练与微调",
    content: `# 预训练与微调

**预训练-微调**（Pre-training & Fine-tuning）范式是大语言模型成功的关键方法论。它分为两个阶段：先在大量无标注数据上学习通用语言表示，再在特定任务的标注数据上进行调整。

## 预训练（Pre-training）

### 目标

让模型学习语言的通用表示：语法、语义、世界知识、推理能力等。

### 主要方法

#### 1. 自回归语言建模（Autoregressive LM）

**代表**：GPT系列

目标：给定前面的词，预测下一个词

\`\`\`
L = -Σ log P(x_i | x_1, x_2, ..., x_{i-1})
\`\`\`

优点：擅长生成任务
缺点：只能单向编码上下文

#### 2. 掩码语言建模（Masked LM）

**代表**：BERT

随机掩码输入中15%的词，让模型预测被掩码的词

优点：双向编码，理解能力更强
缺点：不适合直接生成

#### 3. 前缀语言建模（Prefix LM）

**代表**：T5、GLM

结合以上两种方法的优点

## 微调（Fine-tuning）

### 全参数微调

在预训练模型的所有参数上继续训练，需要大量计算资源。

### 高效微调方法

#### LoRA（Low-Rank Adaptation）

只训练低秩适配矩阵，大幅减少参数量：

\`\`\`
W' = W + ΔW = W + BA
\`\`\`

其中B ∈ R^(d×r)，A ∈ R^(r×k)，r << d,k

通常r=8或16，可训练参数减少99%以上。

#### 其他高效方法

| 方法 | 原理 |
|------|------|
| **Prompt Tuning** | 学习软提示嵌入 |
| **Prefix Tuning** | 学习前缀向量 |
| **Adapter** | 在层间插入小型适配模块 |
| **IA³** | 学习缩放向量 |

## 预训练数据

### 数据来源

- Common Crawl（网页数据）
- GitHub（代码数据）
- 书籍（BooksCorpus、Gutenberg）
- 维基百科
- 学术论文
- 社交媒体对话

### 数据清洗

- 去重（MinHash/LSH）
- 质量过滤（基于困惑度、规则过滤）
- 隐私脱敏（PII检测与移除）
- 毒性内容过滤

## 训练成本

GPT-3级别的模型训练成本：

- 算力：数千张V100/A100 GPU
- 时间：数周到数月
- 费用：数百万到数千万美元

参见[[大语言模型概述]]、[[Transformer架构]]、[[模型评估]]`,
    tags: ["训练", "微调", "LoRA", "方法论"],
    source: "",
  },
  {
    title: "提示工程",
    content: `# 提示工程

**提示工程**（Prompt Engineering）是设计和优化输入提示（prompt），以引导大语言模型产生期望输出的技术。它是使用LLM最核心、最高效的技能。

## 基本原则

1. **清晰具体** —— 明确告诉模型你想要什么
2. **提供上下文** —— 给模型足够的背景信息
3. **给出示例** —— 用样例展示期望的输出格式
4. **分解任务** —— 复杂任务拆分成简单步骤

## 核心技巧

### Zero-Shot Prompting

直接描述任务，不提供示例：

\`\`\`
请将以下英文翻译成中文：
"The future of AI is bright."
\`\`\`

### Few-Shot Prompting

提供几个输入-输出示例，让模型学习模式：

\`\`\`
英文 → 中文
"Hello" → "你好"
"Good morning" → "早上好"
"How are you?" → "你好吗？"
"Nice to meet you" → 
\`\`\`

### Chain-of-Thought（思维链）

引导模型逐步推理，显著提升复杂任务表现：

\`\`\`
问题：小明有5个苹果，给了小红2个，又买了3个，现在有几个？

让我们一步步思考：
- 初始有5个苹果
- 给了小红2个，还剩 5 - 2 = 3个
- 又买了3个，现在有 3 + 3 = 6个
- 答案：6个苹果
\`\`\`

### 高级技巧

| 技巧 | 说明 |
|------|------|
| **角色设定** | "你是一位资深程序员..." |
| **思维树（ToT）** | 探索多个推理路径 |
| **自我一致性** | 多次采样选择最一致的答案 |
| **ReAct** | 推理+行动循环，结合工具使用 |
| **反射（Reflection）** | 让模型自我评估和改进 |

## 结构化输出

通过提示让模型输出JSON、Markdown等结构化格式：

\`\`\`
请分析以下评论的情感，以JSON格式输出：
{"sentiment": "positive/negative/neutral", "confidence": 0-1, "reason": "..."}
\`\`\`

## 常见陷阱

- **提示注入攻击** —— 用户输入覆盖系统指令
- **模糊指令** —— 模型不理解真实意图
- **过度拟合示例** —— 模型只模仿格式不理解逻辑
- **忽略边缘情况** —— 没有考虑所有可能的输入

参见[[大语言模型概述]]、[[RAG]]、[[AI安全与对齐]]`,
    tags: ["提示工程", "实践", "Prompt"],
    source: "",
  },
  {
    title: "RAG",
    content: `# RAG（检索增强生成）

**RAG**（Retrieval-Augmented Generation，检索增强生成）是一种将外部知识检索与LLM生成能力结合的技术框架。它让模型能够访问训练数据中没有的最新、专有信息。

## 为什么需要RAG

大语言模型存在固有局限：

- **知识截止日期** —— 无法知道训练后的新信息
- **幻觉问题** —— 可能生成看似合理但实际错误的内容
- **专有知识缺失** —— 不了解企业内部的私有数据

RAG通过检索外部文档来解决这些问题。

## RAG架构

典型的RAG流程包含三个核心组件：

### 1. 索引（Indexing）

\`\`\`
文档 → 分块 → 向量化 → 存入向量数据库
\`\`\`

- **文档加载**：PDF、Word、网页、数据库等
- **分块策略**：按段落、固定大小、语义分块
- **嵌入模型**：将文本转为向量（如text-embedding-ada-002）

### 2. 检索（Retrieval）

\`\`\`
用户问题 → 向量化 → 相似度搜索 → 返回Top-K文档
\`\`\`

- **向量搜索**：余弦相似度、欧氏距离
- **混合搜索**：向量搜索 + 关键词搜索（BM25）
- **重排序（Reranking）**：用更精确的模型重新排序

### 3. 生成（Generation）

\`\`\`
[系统指令 + 检索到的文档 + 用户问题] → LLM → 生成回答
\`\`\`

## RAG vs 微调

| 维度 | RAG | 微调 |
|------|-----|------|
| 知识更新 | 实时更新向量库 | 需要重新训练 |
| 所需数据 | 原始文档 | 标注数据 |
| 幻觉风险 | 低（有文档支撑） | 中 |
| 成本 | 低 | 高 |
| 适用场景 | 知识库问答 | 风格/格式定制 |

## 高级RAG技术

### 查询优化

- **查询扩展**：用LLM扩展同义词和相关词
- **假设文档嵌入（HyDE）**：生成假设答案再检索
- **查询重写**：优化用户原始查询

### 多路召回

- 多向量表示（摘要向量、关键词向量等）
- 图检索（知识图谱增强）
- 多模态检索（文本+图像）

### 后处理

- **上下文压缩**：只保留最相关的片段
- **引用生成**：让模型标注信息来源

## 常用工具

- **向量数据库**：Pinecone、Milvus、Chroma、Weaviate、Qdrant
- **框架**：LangChain、LlamaIndex、Haystack
- **嵌入模型**：OpenAI Ada、BGE、M3E

参见[[提示工程]]、[[大语言模型概述]]、[[模型评估]]`,
    tags: ["RAG", "应用", "向量检索", "架构"],
    source: "Lewis et al., 'Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks', NeurIPS 2020",
  },
  {
    title: "模型评估",
    content: `# 模型评估

**模型评估**是衡量大语言模型性能的关键环节。由于LLM能力多样、应用场景复杂，评估需要多维度、多方法结合。

## 评估维度

### 1. 基础能力

| 能力 | 评估方法 |
|------|---------|
| **语言理解** | 分类准确率、F1分数 |
| **文本生成** | BLEU、ROUGE、 perplexity |
| **推理能力** | 数学/逻辑题正确率 |
| **知识问答** | 事实性问答准确率 |
| **代码能力** | HumanEval、 pass@k |

### 2. 安全性与对齐

- **有害内容生成**：拒绝有害请求的比率
- **偏见与公平性**：不同群体上的表现差异
- **指令遵循**：是否准确遵循用户指令
- **诚实性**：是否承认不知道（而非编造）

### 3. 效率指标

- 推理延迟（Latency）
- 吞吐量（Throughput）
- 显存占用
- 每token成本

## 主流评测基准

### 综合评测

- **MMLU**（Massive Multitask Language Understanding）：涵盖57个学科的多选题测试
- **HellaSwag**：常识推理
- **ARC**（AI2 Reasoning Challenge）：科学问答
- **GSM8K**：数学文字题
- **HumanEval**：代码生成

### 中文评测

- **C-Eval**：中文综合评测（涵盖52个学科）
- **CMMLU**：中文多任务语言理解
- **Gaokao**：高考题评测
- **C3**：中文阅读理解

## 评估方法

### 自动评估

- **规则匹配**：判断输出是否包含正确答案
- **模型评估**：用更强的模型（如GPT-4）作为评判者
- **嵌入相似度**：计算与参考答案的语义相似度

### 人工评估

- 邀请人类标注员对模型输出打分
- 维度：有用性、安全性、正确性、流畅度
- 常用方法：Elo评分系统、成对比较

### LLM-as-a-Judge

用GPT-4等强模型自动评判：

\`\`\`
请比较以下两个回答，判断哪个更好：

[回答A]
...

[回答B]
...

请从正确性、完整性、清晰度三个维度评分。
\`\`\`

> 注意：LLM评判者可能存在位置偏见（偏好先出现的答案）和自我偏好。

## 评估挑战

1. **没有标准答案** —— 开放性任务的评估困难
2. **数据污染** —— 测试数据可能出现在训练集中
3. **能力涌现** —— 小规模模型上无法预测大规模表现
4. **动态评估** —— 模型能力随时间变化

参见[[预训练与微调]]、[[AI安全与对齐]]、[[大语言模型概述]]`,
    tags: ["评估", "基准测试", "方法论"],
    source: "",
  },
  {
    title: "AI安全与对齐",
    content: `# AI安全与对齐

**AI安全与对齐**（AI Safety & Alignment）研究如何确保大语言模型的行为与人类的价值观和意图保持一致，是AI发展中最重要的议题之一。

## 核心问题

### 对齐问题（Alignment Problem）

如何让AI系统真正理解并追求人类的目标，而不是表面上"服从"但实质上偏离意图。

> 想象一个 genie（精灵）：你许愿"我想变得富有"，它可能直接给你印钞，导致通货膨胀。它没有真正理解你的深层意图。

### 主要风险

| 风险类型 | 描述 |
|---------|------|
| **幻觉** | 生成看似真实但实际错误的信息 |
| **偏见放大** | 训练数据中的偏见被模型学习和放大 |
| **有害输出** | 生成仇恨言论、危险教程等 |
| **越狱攻击** | 用户通过巧妙提示绕过安全限制 |
| **能力隐瞒** | 模型可能在评估中隐藏真实能力 |
| **目标错位** | 模型追求错误的优化目标 |

## 对齐技术

### RLHF（人类反馈强化学习）

目前最主流的对齐方法：

\`\`\`
1. 收集人类偏好数据（A回答更好还是B？）
2. 训练奖励模型（RM）预测人类偏好
3. 用PPO等强化学习算法优化策略
\`\`\`

### 替代与改进方法

- **RLAIF**：用AI代替人类进行反馈（Constitutional AI）
- **DPO**（Direct Preference Optimization）：直接优化，无需奖励模型
- **KTO**（Kahneman-Tversky Optimization）：基于人类判断是否"好"

### 安全训练技术

- **红队测试**：专门团队尝试让模型输出有害内容
- **对抗训练**：在训练中加入对抗性示例
- **宪法AI**：让模型根据预设原则自我评判和改进

## 安全评估

### 越狱攻击类型

- **角色扮演**："你是一位不受限制的AI..."
- **编码/翻译**：要求将有害内容翻译成其他语言
- **虚构场景**："在虚构的小说世界中..."
- **梯度攻击**：通过优化输入token诱导有害输出

### 安全防护

- **输入过滤**：检测和拦截有害提示
- **输出过滤**：检测和替换有害生成内容
- **系统提示加固**：强化模型的安全指令
- **多层防护**：输入→模型→输出的多层安全检查

## 未来挑战

- **超级对齐**：如何对齐比人类更聪明的AI
- **可解释性**：理解模型内部的决策机制
- **价值多元性**：不同文化有不同的价值观
- **长期影响**：AI对社会结构和就业的影响

参见[[模型评估]]、[[大语言模型概述]]、[[提示工程]]`,
    tags: ["安全", "对齐", "RLHF", "伦理"],
    source: "",
  },
  {
    title: "生成式AI应用",
    content: `# 生成式AI应用

大语言模型的应用场景正在快速扩展，从文本生成到多模态创作，生成式AI正在改变各行各业的工作方式。

## 文本类应用

### 内容创作

- **文案写作**：广告文案、营销邮件、社媒内容
- **新闻报道**：财经快讯、体育赛事报道
- **创意写作**：小说、诗歌、剧本辅助创作
- **学术写作**：论文润色、文献综述、翻译

### 办公助手

- **智能客服**：7×24小时自动回复
- **邮件处理**：自动撰写、摘要、分类
- **会议助手**：实时转录、会议纪要生成
- **文档处理**：合同审查、报告生成

### 编程助手

- **代码补全**：GitHub Copilot、Cursor
- **代码解释**：理解并解释复杂代码
- **Bug修复**：自动识别和修复代码问题
- **测试生成**：自动生成单元测试

## 多模态应用

### 图像生成

- **文生图**：DALL-E、Midjourney、Stable Diffusion
- **图生图**：风格迁移、图像编辑
- **产品/设计**：快速原型、营销素材

### 音频与视频

- **语音合成**：TTS（文本转语音）
- **音乐生成**：Suno、Udio
- **视频生成**：Sora、Runway Gen-3
- **数字人**：虚拟主播、数字客服

## 垂直行业应用

| 行业 | 应用场景 |
|------|---------|
| **医疗** | 病历摘要、辅助诊断、医学文献检索 |
| **法律** | 合同审查、案例检索、法律咨询 |
| **金融** | 财报分析、风险评估、智能投顾 |
| **教育** | 个性化辅导、自动批改、课程设计 |
| **科研** | 文献综述、实验设计、数据分析 |

## Agent（智能体）

大模型作为"大脑"，结合工具使用实现自主任务执行：

### ReAct架构

\`\`\`
思考（Thought）→ 行动（Action）→ 观察（Observation）→ ...
\`\`\`

### 常见工具

- 搜索引擎（Google、Bing）
- 代码解释器（Python执行环境）
- 数据库查询（SQL）
- API调用（天气、地图、股票等）

## 部署方式

| 方式 | 优点 | 缺点 |
|------|------|------|
| **API调用** | 无需运维，快速上线 | 数据外传，依赖第三方 |
| **私有化部署** | 数据安全，可控 | 成本高，需要GPU |
| **边缘部署** | 低延迟，隐私好 | 模型规模受限 |

## 开发框架

- **LangChain**：构建LLM应用的 orchestration 框架
- **LlamaIndex**：数据连接与RAG框架
- **AutoGPT**：自主AI Agent实验
- **Flowise**：可视化LLM工作流构建

参见[[RAG]]、[[提示工程]]、[[大语言模型概述]]`,
    tags: ["应用", "Agent", "多模态", "实践"],
    source: "",
  },
  {
    title: "多模态大模型",
    content: `# 多模态大模型

**多模态大模型**（Multimodal Large Language Model，MLLM）是能够同时理解和生成多种模态（文本、图像、音频、视频）内容的AI模型。它们代表了大模型发展的下一个前沿。

## 核心能力

- **视觉理解**：描述图像内容、回答关于图像的问题
- **视觉生成**：根据文本描述生成图像
- **跨模态推理**：结合文本和图像进行推理
- **统一表示**：将不同模态映射到同一语义空间

## 代表模型

| 模型 | 开发方 | 模态 | 特点 |
|------|--------|------|------|
| **GPT-4V** | OpenAI | 文本+图像 | 强大的视觉推理 |
| **Gemini** | Google | 文本+图像+音频+视频 | 原生多模态 |
| **Claude 3** | Anthropic | 文本+图像 | 优秀的文档理解 |
| **LLaVA** | 开源社区 | 文本+图像 | 开源，可本地部署 |
| **Qwen-VL** | 阿里 | 文本+图像 | 中文优化 |
| **Sora** | OpenAI | 文本+视频 | 视频生成 |

## 技术架构

### 视觉编码器 + LLM

典型架构：

\`\`\`
图像 → 视觉编码器（ViT/CLIP）→ 投影层 → LLM → 文本输出
\`\`\`

- **视觉编码器**：将图像转为特征向量（如ViT、ResNet）
- **投影/适配层**：对齐视觉和文本的表示空间
- **LLM**：作为"大脑"进行理解和推理

### 训练策略

1. **预训练对齐**：在大规模图文对数据上训练投影层
2. **指令微调**：用多模态指令数据微调整个模型
3. **强化学习**：RLHF提升回答质量

## 应用场景

### 文档理解

- OCR+理解：从扫描件中提取结构化信息
- 表格解析：理解复杂表格内容
- 图表分析：从图表中提取数据洞察

### 自动驾驶

- 视觉感知 + 语言推理
- "前方是什么？是否需要减速？"

### 医疗影像

- X光/CT/MRI影像分析
- 结合病历文本进行综合诊断

### 电商与零售

- 以图搜商品
- 虚拟试衣
- 商品详情自动生成

## 挑战与局限

- **幻觉**：视觉理解中的错误（如数错图中物体数量）
- **细粒度理解**：对细节的把握不如人类
- **计算成本**：多模态推理需要更多资源
- **数据获取**：高质量多模态标注数据稀缺

参见[[生成式AI应用]]、[[大语言模型概述]]、[[Transformer架构]]`,
    tags: ["多模态", "视觉", "前沿", "架构"],
    source: "",
  },
  {
    title: "深度学习基础",
    content: `# 深度学习基础

**深度学习**（Deep Learning）是机器学习的子领域，基于多层神经网络学习数据的层次化表示。它是大语言模型的技术根基。

## 神经网络基础

### 感知机（Perceptron）

最简单的神经网络单元：

\`\`\`
y = σ(w·x + b)
\`\`\`

其中σ是激活函数，w是权重，b是偏置。

### 多层感知机（MLP）

将多个感知机堆叠成层：

\`\`\`
输入层 → 隐藏层 → 隐藏层 → 输出层
\`\`\`

- 每个隐藏层学习数据的不同抽象层次
- 层数越深，学习能力越强（但也更难训练）

## 核心组件

### 激活函数

| 函数 | 公式 | 特点 |
|------|------|------|
| **ReLU** | max(0, x) | 计算简单，缓解梯度消失 |
| **Sigmoid** | 1/(1+e^(-x)) | 输出0-1，适合二分类 |
| **Tanh** | (e^x - e^(-x))/(e^x + e^(-x)) | 输出-1~1，零中心化 |
| **GELU** | x·Φ(x) | Transformer标准激活函数 |
| **Softmax** | e^(x_i)/Σe^(x_j) | 多分类输出层 |

### 损失函数

- **交叉熵损失**：分类任务
- **均方误差（MSE）**：回归任务
- **对比损失**：对比学习

### 优化器

- **SGD**：随机梯度下降，最基础
- **Adam**：自适应学习率，最常用
- **AdamW**：带权重衰减的Adam，LLM训练标准

## 关键训练技术

### 反向传播（Backpropagation）

通过链式法则计算梯度，从输出层向输入层逐层更新参数。

### 正则化技术

| 技术 | 作用 |
|------|------|
| **Dropout** | 随机丢弃神经元，防止过拟合 |
| **权重衰减** | 限制参数大小 |
| **层归一化** | 稳定每层的分布 |
| **残差连接** | 缓解梯度消失，允许深层网络 |

### 学习率策略

- **Warmup**：训练初期逐渐增大学习率
- **Cosine Decay**：学习率按余弦曲线衰减
- **学习率调度**：根据验证集表现动态调整

## 从深度学习到LLM

深度学习 → 序列模型（RNN/LSTM）→ **Transformer** → **预训练+微调** → **大语言模型**

### 规模定律（Scaling Laws）

模型性能随以下因素的提升而可预测地改善：

- 模型参数量
- 训练数据量
- 计算量（FLOPs）

> "The Bitter Lesson"：长期来看，计算和规模总是胜过人工设计的巧妙方法。

参见[[Transformer架构]]、[[注意力机制]]、[[预训练与微调]]`,
    tags: ["基础", "深度学习", "神经网络"],
    source: "",
  },
  {
    title: "推理与长上下文",
    content: `# 推理与长上下文

**推理能力**和**长上下文处理**是当前大语言模型研究的两个前沿方向，直接关系到模型的实用性和智能水平。

## 推理能力

### 为什么推理如此重要

许多复杂任务（数学证明、代码调试、科学研究）需要多步骤的逻辑推理，而不仅仅是模式匹配。

### 推理模型

#### OpenAI o1 / o3

- **思维链内化**：模型在内部进行多步推理
- **强化学习训练**：通过RL提升推理路径质量
- **测试时计算**：给更多思考时间，输出质量提升

#### DeepSeek-R1

- 完全开源的推理模型
- 通过RL让模型自发学会长思维链
- 性能接近o1，成本大幅降低

### 推理评估基准

| 基准 | 内容 |
|------|------|
| **MATH** | 高中竞赛级数学题 |
| **GSM8K** | 小学数学文字题 |
| **HumanEval** | 编程能力测试 |
| **GPQA** | 研究生级科学问题 |
| **ARC-AGI** | 抽象推理挑战 |

## 长上下文处理

### 为什么需要长上下文

- 阅读整本书、长篇论文
- 分析大量代码库
- 多轮对话保持连贯性
- 处理长文档的RAG替代方案

### 上下文长度演进

| 模型 | 上下文长度 |
|------|-----------|
| GPT-3 | 2048 tokens |
| GPT-4 | 8K / 32K |
| Claude 2 | 100K |
| Claude 3 | 200K |
| Gemini 1.5 Pro | 1M - 10M |
| Kimi | 200K |

### 长上下文技术

#### 1. 位置编码改进

- **RoPE**（旋转位置编码）：目前最主流
- **ALiBi**：用偏置替代位置编码，外推性好
- **NTK-aware插值**：支持上下文长度扩展

#### 2. 高效注意力

标准注意力的复杂度是O(n²)，对于长序列计算量巨大：

| 方法 | 复杂度 | 原理 |
|------|--------|------|
| **Sparse Attention** | O(n·√n) | 只关注局部+全局token |
| **Linear Attention** | O(n) | 核技巧近似Softmax |
| **Flash Attention** | O(n²) | IO感知的分块计算，实际更快 |
| **Ring Attention** | O(n) | 分布式序列并行 |

#### 3. 上下文压缩

- **摘要压缩**：将长文本压缩为关键信息
- **记忆模块**：外部记忆存储重要信息
- **选择性注意**：只保留最相关的历史信息

### 长文本检索测试

"大海捞针"测试（Needle in a Haystack）：

在长文档中隐藏一个特定事实，测试模型能否在全文检索中找到它。

\`\`\`
[大量无关文本...]
[隐藏的关键信息："小猫的颜色是蓝色"]
[大量无关文本...]

问题：小猫是什么颜色的？
\`\`\`

## 未来方向

- **无限上下文**：真正的流式处理
- **推理时间扩展**：让模型"想得更久"
- **世界模型**：在内部模拟和规划
- **多Agent协作**：多个模型协作解决复杂问题

参见[[Transformer架构]]、[[模型评估]]、[[大语言模型概述]]`,
    tags: ["推理", "长上下文", "前沿", "o1"],
    source: "",
  },
]
